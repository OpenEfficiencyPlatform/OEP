

Account = 
[
	Name: flowVars.AccountName,
	RecordTypeId: flowVars.DefaultAccountRecordType
]

return [Account]