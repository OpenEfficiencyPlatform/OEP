param(
	[Parameter(Mandatory=$true)]
	[string]$InstanceName,
	[string]$InstallPath='use_default',
	[Parameter(Mandatory=$true)]
	[string]$CompassInstance,
	[Parameter(ValueFromRemainingArguments=$true)]$options
)

$ErrorActionPreference = "Stop"

$defaults = @{}

if ($InstallPath -eq 'use_default') {
	if ($CompassInstance.StartsWith('review')) {
		$InstallPath = 'C:\mule_review'
	}
	elseif ($CompassInstance.StartsWith('staging')) {
		$InstallPath = 'C:\mule_staging'
	}
	else {
		$InstallPath = 'C:\mule'
	}
}

if ($CompassInstance) {
	$defaults.Add('compass.host', $CompassInstance)
	$defaults.Add('compass.port', '80')
	$defaults.Add('compass.protocol', 'HTTP')
	if ($CompassInstance.StartsWith('review') -or $CompassInstance.StartsWith('staging')) {
		# Disable email for non-production services by default
		$defaults.Add('email.host', 'localhost')
	}
}

if ($env:HTTPS -and $env:HTTPS.toLower() -eq "true") {
	$defaults['compass.protocol'] = 'HTTPS'
	$defaults['compass.port'] = '443'
}


# Copy configuration to mule conf directory
$propertiesFile = Join-Path $InstallPath "conf\$InstanceName.properties"
Write-Host "Copying properties file to $propertiesFile"
Copy-Item "Contents\$InstanceName.properties" -Destination $propertiesFile
Configure-Mule $propertiesFile -Defaults $defaults
# Copy application to mule app directory
$applicationFile = Join-Path $InstallPath "apps\$InstanceName.zip"
Write-Host "Copying application to $applicationFile"
Copy-Item Contents\$InstanceName.zip $applicationFile
