from shutil import copyfile
from os.path import join
from optparse import OptionParser
import re
from os import environ
import os

parser = OptionParser()
parser.add_option('--InstanceName')
parser.add_option('--InstallPath')
parser.add_option('--CompassInstance')
(args, oargs) = parser.parse_args()

InstanceName = args.InstanceName
InstallPath = args.InstallPath

if args.InstallPath:
    InstallPath = args.InstallPath
else:
    if args.CompassInstance.startswith("review"):
        InstallPath = "/opt/mule-standalone-3.8.1"
    elif args.CompassInstance.startswith("staging"):
        InstallPath = "/opt/mule-standalone-3.7.0"
    else:
        InstallPath = "/opt/mule-standalone-3.8.1-production"

defaults = {'compass.host':args.CompassInstance,
            'compass.port':'80',
            'compass.protocol':'HTTP'}

if os.getenv('HTTPS', 'false').lower() == 'true':
    defaults['compass.protocol'] = 'HTTPS'
    defaults['compass.port'] = '443'

if args.CompassInstance.startswith('review') or args.CompassInstance.startswith('staging'):
    # Disable email for non-production services by default
    defaults['email.host'] = 'localhost'

def configureMule(propertiesFile, defaults):
    print "Configuring mule at: %s" % propertiesFile

    def replaceWithEnvValue(line):
        m = re.match("^(.+)=.*", line)
        if m:
            varname = m.group(1)
            envvarname = varname.replace('.', '_')
            if envvarname in environ:
                print "Using env variable value for %s" % varname
                return "%s=%s\n" % (varname, environ[envvarname])
            if varname in defaults:
                print "Using default for %s" % varname
                return "%s=%s\n" % (varname, defaults[varname])
        return line

    with open(propertiesFile) as f:
        lines = f.readlines()
    with open(propertiesFile, "w") as f:
        newlines = map(replaceWithEnvValue, lines)
        f.writelines(newlines)


# Copy configuration to mule conf directory
propertiesFile = join(InstallPath, "conf/%s.properties" % args.InstanceName)
print "Copying properties file to %s" % propertiesFile
copyfile("Contents/%s.properties" % args.InstanceName, propertiesFile)
configureMule(propertiesFile, defaults)
# Copy application to mule app directory
applicationFile = join(InstallPath, "apps/%s.zip" % args.InstanceName)
print "Copying application to %s" % applicationFile
copyfile("Contents/%s.zip" % args.InstanceName, applicationFile)

